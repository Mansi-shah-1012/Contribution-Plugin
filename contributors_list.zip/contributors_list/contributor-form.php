<div class="box">
    <style>
        .box{
            display: grid;
            grid-template-columns: max-content 1fr;
            grid-row-gap: 10px;
            grid-column-gap: 20px;
        }
        .custom_field{
            display: contents;
        }
    </style>
    <?php
        $users = get_users();
        foreach($users as $user):
    ?>
    <p class="meta-options custom_field">
        <label for="contributor_author"><?php echo $user->display_name; ?></label>
        <input id="contributor_author" type="checkbox" name="contributor_author[]" value="<?php echo $user->ID; ?>">
    </p>
    <?php endforeach; ?>
</div>