<?php
/*
Plugin Name: Contributor List
Description: Display List of Contributor
Version: 1.0.0
*/


register_activation_hook( __FILE__, 'contributor_activation' );
function contributor_activation(){

}

register_deactivation_hook( __FILE__, 'contributor_deactivation' );
function contributor_deactivation(){

}

/**
 * Register meta boxes.
 */
function add_contributor_meta_boxes() {
    add_meta_box( 'contributor', __( 'Contributor List', 'contributor_list' ), 'contributor_display_callback', 'post' );
}
add_action( 'add_meta_boxes', 'add_contributor_meta_boxes' );

/**
 * Meta box display callback.
 */
function contributor_display_callback() {
    include plugin_dir_path( __FILE__ ) . './contributor-form.php';
}

/**
 * Save meta box content.
 */
add_action( 'save_post', 'contributor_save_meta_box' );
function contributor_save_meta_box( $post_id ) {
    $fields = [
        'contributor_author'
    ];
    foreach ( $fields as $field ) {
        if ( array_key_exists( $field, $_POST ) ) {
            update_post_meta( $post_id, $field, json_encode($_POST[$field]) );
        }
    }
}

/**
 * Display Contributor at Post Content
 */
function display_contributor(){
    global $post;
    $contributors = get_post_meta( $post->ID, 'contributor_author', true );
    $html = '';
    if(!empty($contributors)){
        $html = '<div><h2>Contributors</h2>';
        foreach(json_decode($contributors) as $contributor){
            $the_user = get_user_by( 'id',  $contributor);
            $display = $the_user->display_name;
            $slug = get_author_posts_url($contributor);
            $img = get_avatar($contributor, 80);
            $html .= '<a href="'.$slug.'"><p>'.$display.'</p></a>';
            $html .= $img;
        }
        $html .= '</div>';
    }else{
        $html = 'No Contributor Found';
    }
    return $html;
}
add_filter('the_content', 'display_contributor');